package com.employeeManagement.junit.testing;

import static org.junit.Assert.assertEquals;

import org.junit.Test;

import com.employeeManagement.entity.Employee;
import com.employeeManagement.service.EmployeeService;

public class JunitTesting {

	private	EmployeeService empService= new EmployeeService();
	@Test
	public void addEmpTest() {
		Employee employee = new Employee();
	empService.addEmployee( employee);
	
	assertEquals(employee,employee);
	}

}
