package com.employeeManagement.photo;

import javax.persistence.Lob;

import lombok.Data;
@Data
public class Photo{

	private String name;
	@Lob
	private byte[] data;
	public Photo(String name, byte[] data) {
		super();
		this.name = name;
		this.data = data;
	}
	
}
